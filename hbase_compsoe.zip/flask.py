import happybase
import socket
from thrift.transport.TTransport import TTransportException

def check_hbase_connection(host='localhost', port=9090):
    try:
        # Try to connect to the HBase server
        connection = happybase.Connection(host=host, port=port, timeout=10)
        connection.open()

        # If we are connected, list tables
        tables = connection.tables()
        print(f"Connection successful! HBase is running. Tables: {tables}")
        connection.close()
    except socket.timeout:
        print(f"Connection to HBase timed out at {host}:{port}.")
    except TTransportException as e:
        print(f"Failed to connect to HBase at {host}:{port}. Error: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")

# Test HBase connection
check_hbase_connection(host='localhost', port=9090)
